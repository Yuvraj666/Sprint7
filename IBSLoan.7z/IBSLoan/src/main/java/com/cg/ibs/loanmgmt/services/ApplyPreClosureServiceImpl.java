package com.cg.ibs.loanmgmt.services;

import java.math.BigInteger;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.ibs.loanmgmt.models.CustomerBean;
import com.cg.ibs.loanmgmt.models.LoanMaster;
import com.cg.ibs.loanmgmt.models.LoanStatus;
import com.cg.ibs.loanmgmt.repositories.LoanMasterDao;
import com.sun.istack.logging.Logger;

@Service
public class ApplyPreClosureServiceImpl implements ApplyPreClosureService {
	private static Logger LOGGER = Logger.getLogger(ApplyPreClosureServiceImpl.class);
	@Autowired
	private LoanMasterDao loanMasterDao;

	@Override
	public List<LoanMaster> getApprovedLoanListByUci(CustomerBean customer) {
		LOGGER.info("Fetching all active loans with uci");
		return loanMasterDao.getApprovedLoanListByUci(customer);

	}

	@Override
	public boolean verifyPreClosureApplicable(BigInteger loanAccNum) {
			LOGGER.info("Verifying the preClosure applicability.");
			boolean check = false;
			LoanMaster loanMaster = loanMasterDao.getLoanByLoanNumber(loanAccNum);
			if (loanMaster.getNumOfEmisPaid() >= 0.25 * loanMaster.getTotalNumOfEmis()) {
				check = true;
			}
			return check;

	}

	@Override
	public LoanMaster getLoanDetails(BigInteger loanAccNumber) {
			LOGGER.info("Loan Details are being fetched using loan number");
			return loanMasterDao.getLoanByLoanNumber(loanAccNumber);
		}

	@Override
	@Transactional
	public void updatePreClosure(LoanMaster loanMaster) {
			LOGGER.info("Updating the preClosure amount.");
			loanMaster.setStatus(LoanStatus.PRE_CLOSURE_VERIFICATION);
			loanMaster.getSavingsAccount()
					.setBalance(loanMaster.getSavingsAccount().getBalance().subtract(loanMaster.getBalance()));
			loanMasterDao.updatePreClosureDao(loanMaster);
		
	}
	
	
	
	

}
