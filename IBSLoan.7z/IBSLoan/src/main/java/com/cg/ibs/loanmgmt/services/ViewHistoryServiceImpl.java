package com.cg.ibs.loanmgmt.services;

import java.util.Collections;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.ibs.loanmgmt.models.CustomerBean;
import com.cg.ibs.loanmgmt.models.LoanMaster;
import com.cg.ibs.loanmgmt.repositories.CustomerDao;
import com.cg.ibs.loanmgmt.repositories.LoanMasterDao;
import com.cg.ibs.loanmgmt.util.ComparatorUtil;

@Service
public class ViewHistoryServiceImpl implements ViewHistoryService {
	@Autowired
	private LoanMasterDao loanMasterDao;
	@Autowired
	private CustomerDao customerDao;

	@Override
	public List<LoanMaster> getAllLoans(CustomerBean loggedInCustomer) {
		return loanMasterDao.getLoanListByUci(loggedInCustomer);
	}

	@Override
	public List<LoanMaster> sortLoans(List<LoanMaster> allLoans, String fieldSort) {
		Collections.sort(allLoans, ComparatorUtil.<LoanMaster>getComparatorOnField(LoanMaster.class, fieldSort));
		return allLoans;
	}

	@Override
	public CustomerBean getCustomer(String userId) {
		return customerDao.getCustomerByUserId(userId);
	}

}
