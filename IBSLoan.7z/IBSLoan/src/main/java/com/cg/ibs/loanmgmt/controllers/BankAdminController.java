package com.cg.ibs.loanmgmt.controllers;

import java.math.BigInteger;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.cg.ibs.loanmgmt.models.BankAdmins;
import com.cg.ibs.loanmgmt.models.CustomerBean;
import com.cg.ibs.loanmgmt.models.LoanMaster;
import com.cg.ibs.loanmgmt.models.LoanStatus;
import com.cg.ibs.loanmgmt.models.LoanType;
import com.cg.ibs.loanmgmt.models.LoanTypeBean;
import com.cg.ibs.loanmgmt.services.ApplyLoanService;
import com.cg.ibs.loanmgmt.services.BankAdminService;
import com.cg.ibs.loanmgmt.services.CustomerService;
import com.cg.ibs.loanmgmt.services.VerifyLoanService;
import com.cg.ibs.loanmgmt.services.VerifyPreclosureService;

@RestController
public class BankAdminController {
	@Autowired
	private BankAdminService bankAdminService;
	@Autowired
	private VerifyLoanService verifyLoanService;
	@Autowired
	private CustomerService customerService;
	@Autowired
	private ApplyLoanService applyLoanService;
	

	BankAdmins loggedInBankAdmin = new BankAdmins();
	LoanMaster globalLoanMaster = new LoanMaster();

	@GetMapping( "/bankAdmin/{userId}")
	public ResponseEntity<String> loginRole(@PathVariable("userId") String userId) {
		ResponseEntity<String> result;
		loggedInBankAdmin = bankAdminService.getBankAdmin(userId);
		if (userId == null) {
			result = new ResponseEntity<>("No User Details Received", HttpStatus.BAD_REQUEST);
		} else {
			result = new ResponseEntity<>("Welcome " + loggedInBankAdmin.getAdminId(), HttpStatus.OK);

		}
		
		
		return result;
	}

	@RequestMapping(value = "/verifyLoan")
	public ModelAndView viewPendingLoans() {
		List<LoanMaster> pendingLoans = verifyLoanService.getSentForVerificationLoans(loggedInBankAdmin);
		ModelAndView mv = new ModelAndView();
		mv.addObject("pendingLoans", pendingLoans);
		System.out.println(pendingLoans);
		mv.setViewName("verifyLoanPage");
		return mv;
	}

	@RequestMapping(value = "/verifyLoan1")
	public ModelAndView sendCustomerDetails(@RequestParam("custUci") BigInteger uci) {
		List<LoanMaster> pendingLoans = verifyLoanService.getSentForVerificationLoans(loggedInBankAdmin);
		ModelAndView mv4 = new ModelAndView();
		mv4.addObject("pendingLoans", pendingLoans);
		CustomerBean cust = verifyLoanService.getCustomerFromUci(uci);
		mv4.addObject("cust", cust);
		mv4.setViewName("verifyLoanPage");
		return mv4;

	}

	@RequestMapping(value = "/verifyLoan2")
	public ModelAndView selectLoanVerify(@RequestParam("appNo") BigInteger loanApplicationNumber) {
		globalLoanMaster.setApplicationNumber(loanApplicationNumber);
		ModelAndView mv5 = new ModelAndView();
		List<LoanMaster> pendingLoans = verifyLoanService.getSentForVerificationLoans(loggedInBankAdmin);
		mv5.addObject("pendingLoans", pendingLoans);
		mv5.addObject("lApplicationNo", loanApplicationNumber);
		mv5.setViewName("verifyLoanPage");
		return mv5;
	}

	@RequestMapping(value = "/verifyLoan3")
	public ModelAndView viewCompleteDetails() {
		ModelAndView mv6 = new ModelAndView();
		globalLoanMaster = verifyLoanService.getLoanByApplicantNum(globalLoanMaster.getApplicationNumber());
		mv6.addObject("lMaster", globalLoanMaster);
		mv6.setViewName("verifyLoanPage");
		return mv6;
	}

//	@RequestMapping(value = "/verifyLoan4")
//	public ModelAndView downloadDoc() {
//		return null;
//	}

	@RequestMapping(value = "/verifyLoan5")
	public ModelAndView updateLoanPostVerify(@RequestParam("appLoan") Integer choice) {
		ModelAndView mv3 = new ModelAndView();
		mv3.setViewName("verifyLoanPage");
		if (choice == 1) {
			globalLoanMaster.setStatus(LoanStatus.APPROVED);
			globalLoanMaster.setApprovedDate(LocalDate.now());
			globalLoanMaster.setNextEmiDate(LocalDate.now().plusMonths(1));
			globalLoanMaster.setTotalNumOfEmis(globalLoanMaster.getLoanTenure());
			globalLoanMaster.setNumOfEmisPaid(0);
			globalLoanMaster.getSavingsAccount().setBalance(globalLoanMaster.getLoanAmount());
			globalLoanMaster = verifyLoanService.updateLoanPostVerify(globalLoanMaster);
			mv3.addObject("msgupdate",
					"Loan has been approved with loan number" + globalLoanMaster.getLoanAccountNumber());
		} else {
			globalLoanMaster.setStatus(LoanStatus.DENIED);
			globalLoanMaster = verifyLoanService.updateLoanPostDenial(globalLoanMaster);
			mv3.addObject("msgupdate", "Loan has been declined.");
		}
		return mv3;
	}
	
//	@RequestMapping(value="/verifyPreclosure")
//	public ModelAndView viewPendingPreClosure() {
//		ModelAndView modelAndView = new ModelAndView();
//		List<LoanMaster> pendingPreclosure = verifyPreclosureService.getSentForVerificationPreclosure(loggedInBankAdmin);
//		
//		modelAndView.addObject("pendingPreclosure", pendingPreclosure);
//		System.out.println(pendingPreclosure);
//		modelAndView.setViewName("verifyPreclosurePage");
//
//		return modelAndView;
//	}
}
