package com.cg.ibs.loanmgmt.services;

import java.util.List;

import com.cg.ibs.loanmgmt.models.BankAdmins;
import com.cg.ibs.loanmgmt.models.LoanMaster;

public interface VerifyPreclosureService {

	List<LoanMaster> getSentForVerificationPreclosure(BankAdmins loggedInBankAdmin);

	LoanMaster updatePreclosurePostVerify(LoanMaster globalLoanMaster);

	LoanMaster updatePreclosurePostDenial(LoanMaster globalLoanMaster);

}
